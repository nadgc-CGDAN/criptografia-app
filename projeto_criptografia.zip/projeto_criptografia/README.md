# Projeto de Comunicação Criptografada

Este projeto permite comunicação segura entre duas aplicações usando AES, DES, RSA e criptografia híbrida.

## Executar
pip install -r requirements.txt
streamlit run app_streamlit.py
