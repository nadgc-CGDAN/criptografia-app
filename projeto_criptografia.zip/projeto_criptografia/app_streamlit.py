import streamlit as st

st.title('Comunicação Criptografada')

st.write('Escolha o algoritmo e digite sua mensagem:')