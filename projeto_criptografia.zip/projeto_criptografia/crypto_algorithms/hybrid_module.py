def hybrid_encrypt(text): return 'hybrid_' + text
def hybrid_decrypt(ciphertext): return ciphertext.replace('hybrid_', '')