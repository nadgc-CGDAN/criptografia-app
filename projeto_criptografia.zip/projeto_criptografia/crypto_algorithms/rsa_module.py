def encrypt_rsa(text): return 'rsa_' + text
def decrypt_rsa(ciphertext): return ciphertext.replace('rsa_', '')