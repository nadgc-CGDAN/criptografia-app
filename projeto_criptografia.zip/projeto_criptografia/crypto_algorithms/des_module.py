def encrypt_des(text): return 'des_' + text
def decrypt_des(ciphertext): return ciphertext.replace('des_', '')