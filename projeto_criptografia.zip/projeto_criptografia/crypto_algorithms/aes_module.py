def encrypt_aes(text): return 'aes_' + text
def decrypt_aes(ciphertext): return ciphertext.replace('aes_', '')